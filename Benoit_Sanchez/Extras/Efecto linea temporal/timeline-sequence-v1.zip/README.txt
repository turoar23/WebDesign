A Pen created at CodePen.io. You can find this one at http://codepen.io/xander1820/pen/pbJRba.

 