A Pen created at CodePen.io. You can find this one at http://codepen.io/jeffglenn/pen/KNYoKa.

 CSS only timeline for a client. Mobile styles coming soon.