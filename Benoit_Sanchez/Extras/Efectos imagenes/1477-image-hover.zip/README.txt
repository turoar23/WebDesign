A Pen created at CodePen.io. You can find this one at http://codepen.io/littlesnippets/pen/bpMmBO.

 Image and title with caption on hover.