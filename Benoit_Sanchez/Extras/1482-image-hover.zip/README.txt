A Pen created at CodePen.io. You can find this one at http://codepen.io/littlesnippets/pen/bpmmNB.

 Image with title and caption on hover.