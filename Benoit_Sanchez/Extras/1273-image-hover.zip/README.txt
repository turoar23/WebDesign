A Pen created at CodePen.io. You can find this one at http://codepen.io/littlesnippets/pen/LGpgGJ.

 Image hover with title and caption